	INSERT INTO tbl_usuario (usua_ced, usua_nom, usua_cel, usua_ema, usua_pas, usua_img, usua_dir, usua_rol, usua_est) VALUES
	('1069756463', 'Andres Torres', '3138746366', 'andrestorres@develtec.net', 'caf1a3dfb505ffed0d024130f58c5cfa', 'public/img/user/1234567.jpg', 'Centro, Fusa', 'Super administrador', 'Activo'),
	('1233511890', 'Yezny Garcia', '', 'yyormarygarcia@ucundinamarca.edu.co', '73e22a14baeebf87b7af53a2d29070d7', 'public/img/user/1233511890.jpg', '', 'Administrador', 'Activo'),
	('1069457652', 'Mateo Galvis', '', 'mgalvisd@ucundinamarca.edu.co', '42c26fc69ccf0ea29cd292956c10267f', 'public/img/user/1069457652.jpg', '', 'Administrador', 'Activo'),
	('1067123345', 'Camilo Garzon', '', 'bcgarzon@ucundinamarca.edu.co', '2cb9da9eabe6fc8d4f7144a0b87459b6', 'public/img/user/1067123345.jpg', '', 'Operario', 'Activo');
	
	INSERT INTO tbl_parqueadero (parq_nom, parq_des, parq_tar, parq_log, parq_lat, parq_cap, parq_fot) VALUES
	('Parqueadero la palma', 'Descripción del parqueadero', '2500', '-74.362679', '4.347035', '15', 'public/img/parking/parqueadero1.jpg');
