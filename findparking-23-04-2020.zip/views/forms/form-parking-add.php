<form enctype="multipart/form-data" method="POST" autocomplete="off">
	<div class="form-row align-items-center">
	  	<div class="col-sm-6 my-1">
	  		<div class="form-group">
			    <label for="parq_nom">Nombre del parqueadero:</label>
	    		<input type="text" name="parq_nom" class="form-control" id="add_parq_nom"  required autocomplete="off"> 
	    	</div>
	  	</div>
	  	<div class="col-sm-3 my-1">
	  		<div class="form-group">
			    <label for="parq_log">Longitud:</label>
	    		<input type="text" name="parq_log" class="form-control" id="add_parq_log"  required autocomplete="off"> 
	    	</div>
	  	</div>
	  	<div class="col-sm-3 my-1">
	  		<div class="form-group">
			    <label for="parq_lat">Latitud:</label>
	    		<input type="text" name="parq_lat" class="form-control" id="add_parq_lat"  required autocomplete="off"> 
	    	</div>
	  	</div>
	</div>
	<div class="form-row align-items-center">
		<div class="col-sm-12 my-1">
	  		<div class="form-group">
			    <label for="parq_des">Descripción:</label>
			    <textarea name="parq_des" class="form-control" id="add_parq_des"></textarea>
	    	</div>
	  	</div>
	</div>
	<div class="form-row align-items-center">
		<div class="col-sm-3 my-1">
	  		<div class="form-group">
			    <label for="parq_tar">Tarifa hora:</label>
	    		<input type="text" name="parq_tar" class="form-control" id="add_parq_tar"  required autocomplete="off"> 
	    	</div>
	  	</div>
	  	<div class="col-sm-3 my-1">
	  		<div class="form-group">
			    <label for="parq_cap">Capacidad:</label>
	    		<input type="text" name="parq_cap" class="form-control" id="add_parq_cap"  required autocomplete="off"> 
	    	</div>
	  	</div>
		<div class="col-sm-6 my-1">
            <div class="form-group">
		        <label>Cargar imagen</label>
		        <div class="input-group add-image-preview">
		            <input type="text" class="form-control image-preview-filename" id="add_parq_fot" disabled="disabled">
		            <span class="input-group-btn">
		                <button type="button" class="btn btn-secondary image-preview-clear" id="add-image-preview-clear" style="display:none;">
		                    <span class="fa fa-times"></span> Quitar
		                </button>
		                <input type="hidden" name="MAX_FILE_SIZE" value="5000000" />
		                <div class="btn btn-secondary image-preview-input" id="add-image-preview-input" data-placement="top">
		                    <span class="fa fa-upload"></span>
		                    <span class="image-preview-input-title" id="add-input-img-title">Subir</span>
		                    <input type="file" accept="image/png, image/jpeg, image/gif" id="add-inp-usa_img" name="parq_fot" required />
		                </div>
		            </span>
		        </div>
		    </div>
        </div>
    </div>
    <button type="button" class="btn btn-secondary" data-dismiss="modal">X</button>
    <button type="button" class="btn btn-primary">Registrar</button>
</form>
<script type="text/javascript">
	function limpiar_add(){
		$('.add-image-preview').attr("data-content","").popover('hide');
        $('#add_usua_img').val("");
        $('#add-image-preview-clear').hide();
        $('#add-image-preview-input input:file').val("");
        $("#add-input-img-title").text("Subir");
	};
</script>