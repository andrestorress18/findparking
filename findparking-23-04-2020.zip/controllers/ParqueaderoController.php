<?php
class ParqueaderoController {
    private $model;

    public function __construct() {
        $this->model = new ParqueaderoModel();
    }
    
    public function set($parq_data = array()) {
        return $this->model->set($parq_data);
    }

    public function get($parq_id = '') {
        return $this->model->get($parq_id);
    }

    public function del($parq_id = '') {
        return $this->model->del($parq_id);
    }
    
}
