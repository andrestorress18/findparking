<?php
class ParqueaderoModel extends Model {

    public function set($parq_data = array()) {
        foreach ($parq_data as $key => $value) {
            $$key = $value;
        }
        $this->query = "REPLACE INTO tbl_parqueadero (parq_id, parq_nom, parq_des) VALUES ($parq_id, '$parq_nom', '$parq_des');";
        $id_reg = $this->set_query();
        return $id_reg;
    }

    public function get($parq_id = '') {
        $this->query = ($parq_id != '')
        ? "SELECT * FROM tbl_parqueadero WHERE parq_id = $parq_id"
        : 'SELECT * FROM tbl_parqueadero ';
        $this->get_query();
        $data = array();
        foreach ($this->rows as $key => $value) {
            array_push($data, $value);
        }
        return $data;
    }

    public function del($parq_id = '') {
        $this->query = "DELETE FROM tbl_parqueadero WHERE parq_id = $parq_id";
        $this->set_query();
    }

}
