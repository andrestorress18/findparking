<div class="e404 container-flex cont-just-cen cont-ialg-cent" >
	<div class="container-e404">
		<img src="./public/img/system/findparking-error-404.png" alt="Recurso no encontrado">
		<div class="e404-text">
			<h4>La URL <b><?php echo $_GET['r']; ?></b> no se encontró en este servidor.</h4>
			<h6>Eso es todo lo que sabemos.</h6>
			<button type="button" class="btn btn-secondary btn-sm" onclick="history.back()"><i class="fa fa-chevron-left"></i> Regresar</button>
		</div>
	</div>	
</div>