<form enctype="multipart/form-data" method="POST" autocomplete="off">
	<center><p>Esta seguro que desa eliminar este registro </p></center>
	<center><button type="submit" class="btn btn-danger">SI</button>
	<button type="button" class="btn btn-success" data-dismiss="modal">NO</button></center>
	<input type="hidden" name="crud" value="del">
	<input type="hidden" id="del_comp_cod" name="comp_cod" >
	<input type="hidden" id="del_cupa_cod" name="cupa_cod" value="" >
</form>
