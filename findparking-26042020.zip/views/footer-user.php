<?php 
print('
			</div>
  		</div>	
  	</div>
</body>
<script>
  $(document).ready( function () {
    $("#tablaModel").DataTable();
  });
</script>
<script src="./public/js/findparking.js"></script>
<footer></footer>
</html>
');