<?php 
print('
</body>
<script src="./public/js/findparking.js"></script>
<footer>	
	<div class="vs-fot-copy">
	Copyright © Find Parking 2020 | UdeC - Universidad de Cundinamarca
	</div>
</footer>
</html>
');